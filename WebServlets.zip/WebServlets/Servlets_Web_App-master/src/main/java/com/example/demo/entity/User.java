package com.example.demo.entity;

public class User extends AbstractEntity{
    //todo
}
